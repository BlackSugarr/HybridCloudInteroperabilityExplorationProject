#!/bin/bash
for i in 1 2; do kill %$i; done