#!/bin/bash
for i in 1 2; do while : ; do : ; done & done