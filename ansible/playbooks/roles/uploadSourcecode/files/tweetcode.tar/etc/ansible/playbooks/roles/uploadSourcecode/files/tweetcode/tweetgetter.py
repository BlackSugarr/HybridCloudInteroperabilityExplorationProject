import urllib, json, pprint, time
import tweepy
import sys
import ssl
from functools import wraps
from pattern.en import sentiment
from TweetStore import TweetStore
from TwitterAPI.TwitterAPI import TwitterAPI

# ---- couchdb variables ----------------
USERNAME = ''
PASSWORD = ''
TARGET_URL = '127.0.0.1'
TARGET_DB = 'tweet_db'

if (USERNAME == '') or (PASSWORD == ''):
    COUCH_SERVER = 'http://'+TARGET_URL+':5984/'
else:
    COUCH_SERVER = 'http://'+USERNAME+':'+PASSWORD+'@'+TARGET_URL+':5984/'

storage = TweetStore(TARGET_DB, COUCH_SERVER)



emotionDict = {}

# load the dictionary
with open('emotionDict', 'r') as f:
    emotionDict = json.loads(f.readline())
    print emotionDict


# calculate the sentiment score,return a score
def getScore(tweets, emotionDict):

    # get the basic Score for text of tweets
    basicScore = sentiment(tweets)[0]

    # store the
    emotionScore = 0
    emotionNumber = 0

    # retrivel the Dictionary find the corresponding adjective
    for key in emotionDict.keys():
        if key in tweets:
            emotionScore = emotionScore + sentiment(emotionDict[key])[0]
            emotionNumber += 1

    if emotionNumber == 0:
        return basicScore
    else:
        finalScore = (basicScore + emotionScore / emotionNumber) / 2
        return finalScore


##################################################



#---- To set the key variables -------------------
# which chunk to listen
chunk_index = 0

# set which key to use to retrieve the twitters
key_index = 0

# set where to store the data
#T_file_path = "data/tweets"
#U_file_path = "data/users"
# get input variables and assign them
if(len(sys.argv)>=3):
    if(sys.argv[1]):
        chunk_index = int(sys.argv[1])
    if(sys.argv[2]):
        key_index = int(sys.argv[2])
    #if(sys.argv[3]):
     #   T_file_path = sys.argv[3]
    #if(sys.argv[4]):
     #   U_file_path = sys.argv[4]
else:
    print "not enough arguments. Please enter the chunk&key index."

# the rate limit, default 1000, if set to -1, no limit
#limit = 1000
#if(len(sys.argv)>=6):
#    if(sys.argv[5]):
#        limit = int(sys.argv[5])

#if limit == -1:
#    print "NO LIMIT for how much twitter to gather"

# -----this section for setting the keys-----
consumer_key = "7wSaGEEGsc8EtFEhNMzXZ0kNB"
consumer_secret = "YFcCFCCdb49jjtnkUXrhf99ySmRMvS2Ox78Uf7rFYej75N63cM"
access_key = "1395955543-tFPBZpFWYKJ8gaWxFH4O62ICqhyls9KpxUmiI3T"
access_secret = "Ko5oFpC4HedChEDWTMif7mVyqGi2WtL9sDoEoZRP4doXV"
randy = [consumer_key,consumer_secret,access_key,access_secret]

consumer_key = "n4l0QyWO7qmAJ62mWXax86iph"
consumer_secret = "mn57R52iLVZCiYQ03t6iRFuH2B1VNZCNLHjQJa1INl1ZrovfVy"
access_key = "2578378782-nFYBLOMRpvC65nHQt04evI3yryqKmgoR27W8nuP"
access_secret = "AFzXVNd79k3l9IJRflKEeTAySeKQ3uqqo4iLaXyJzbEux"
lizy = [consumer_key,consumer_secret,access_key,access_secret]

consumer_key = 'Vx4oKEuNBMOj9m3j32u16I92F'
consumer_secret = 'HU2uCUmsKCr5W3BitfyF54QmiAEtjeaeO1r7H2ObTcvBCGU0RJ' 
access_key = '3163929288-PIHT99H2DGqxwamsGNQlL5NfjZkjBgH5wUmXUmW'
access_secret = 'tev5R42Kxrw2SsE6R4zMd0U2kdUTH5J11UcgtKqtcrqpE'
shawn = [consumer_key,consumer_secret,access_key,access_secret]

consumer_key = "pHEXlHn2pnW1PaRCmvrhMNMj7"
consumer_secret = "BRavVRFef2dt3SZ17kLD2gsZ8iwUwkQib3eptWEzizxI6NbJrB"
access_key= "3165109069-rP6vQD8hJrLSa6utYMLrKpvhfo1RIROkdNvv9jE"
access_secret= "eKsGSBDVKkKg1JNsqTiBptRccUcuoAaBaSkuDIAZqU46D"
ivan = [consumer_key,consumer_secret,access_key,access_secret]

consumer_key = "lSjoTqZ4ofmtCr0uh7aJZRQcp"
consumer_secret = "qfkI0RjyOetHNDE6EJhojNlqRf4B7lbZj2rTQBmTZYHT9sRjlc"
access_key = "3186003008-eAzy3mSzxHRYuWzji65Xi0JrjTFqJTO81MU2cKK"
access_secret = "Rvvo931v0hbMyRX8sg8QG51cVlY8LQuij8zXuA9aP1hIh"
new = [consumer_key,consumer_secret,access_key,access_secret]

keys = [randy,lizy,shawn,ivan,new]
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#here would decide which key index is used.
#auth = tweepy.OAuthHandler(keys[key_index][0], keys[key_index][1])
#auth.set_access_token(keys[key_index][2], keys[key_index][3])
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


# ----- Information about the city bound and chunks -------
# get the city bound with "map_google.py"; reminder:need install geopy.
city_bound_googleV3 = [-84.5518189, 33.648079, -84.289389,33.8876179]
# check the value of chunks bound with "square_divide.py".
# test it with [0,0,100,100] to see how it works.
chunks_bound = [[-84.5518189, 33.648079, -84.42060395, 33.76784845], \
                [-84.5518189, 33.76784845, -84.42060395, 33.8876179], \
                [-84.42060395, 33.648079, -84.289389, 33.76784845],\
                [-84.42060395, 33.76784845, -84.289389, 33.8876179]]

# chose which chunk/district to gather twitter, the chunk of distribution is shown as below
#==========
#==12==22==
#==========
#==11==21==
#========== 
# set for creating twitter file.
chunk_to_filename = ["C11","C12","C21","C22"]

# Actually, I dont know what this does, someone claims it replaced a function to support better/newer ssl.
# and it seems did a good job.
def sslwrap(func):
    @wraps(func)
    def bar(*args, **kw):
        kw['ssl_version'] = ssl.PROTOCOL_TLSv1
        return func(*args, **kw)
    return bar
ssl.wrap_socket = sslwrap(ssl.wrap_socket)

#---- finnally, main function here ------------
#---- Everyone, get in here/Everyone, get in here-------
#---- get the files to store the tweets and users-------
#T_file = open(T_file_path,'a')
#U_file = open(U_file_path,'a')


TWITTER_ENDPOINT = 'statuses/filter'
TWITTER_PARAMS = {'locations':chunks_bound[chunk_index]}

#api = TwitterAPI(keys[key_index][0], keys[key_index][1], keys[key_index][2], keys[key_index][3])
api = TwitterAPI(keys[key_index][0], keys[key_index][1], keys[key_index][2], keys[key_index][3])

max_tweets_per_hr  = 115
download_pause_sec = 3600 / max_tweets_per_hr

for item in api.request(TWITTER_ENDPOINT, TWITTER_PARAMS):
    if 'text' in item:
        item['sentiment'] = getScore(item['text'],emotionDict) # plus code here#
        print('%s -- %s\n' % (item['user']['screen_name'].encode('utf8'), item['text'].encode('utf8')))
        storage.save_tweet(item)
    elif 'message' in item:
        print('ERROR %s: %s\n' % (item['code'], item['message']))
    print '    pausing %d sec to obey Twitter API rate limits' % \
                      (download_pause_sec)
    time.sleep( download_pause_sec )
